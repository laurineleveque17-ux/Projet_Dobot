import cv2
import numpy as np
import threading
import queue
import time
import math
import DobotDllType as dType

# --- PARAMÈTRES DE CALIBRATION ---
mire_px = 621.03
mire_mm = 200
px_en_mm = mire_mm / mire_px

# Définition écran / Caméra
ecran_largeur = 1920
ecran_hauteur = 1080

x_center_frame_px = 906 #px
y_center_frame_px = 406 #px
angle_frame_robot = 0.55 # en degrés
angle_rad = math.radians(angle_frame_robot) # conversion en radians pour les calculs trigonométriques
offset_angle_robot = -7 + 90 # rectification de l'angle de la pince en degrés (-7 correspond à un mauvais alignement de la pince sur le robot et +90 permet d'avoir la pince bien orientée pour attraper les cubes dans le sens de leur déplacement sur le tapis)

# Masque Vision (Zone de travail)
x_vision = 400  # mm
y_vision = 100  # mm
mask_offset_x = 50  # mm 
mask_offset_y = 0  # mm

# Détection cube
seuil = 120
area_min = 900
area_max = 3000
same_cube_distance = 20 #px
tolerance_angle = 0.2
last_sent_time = 0

# Paramètre envoi
time_remove_after_sending = 7 # secondes après l'envoi du cube à la file d'attente pour le retirer de la liste des cubes détectés
send_line = 60 # mm 

# Zone atteignable
# Rayon minimum (Zone proche de la base impossible à atteindre)
R_MIN = 250 #200
# Rayon maximum (Extension complète du bras)
R_MAX = 300

pas_point_attrape = 10 # mm escpace entre les points testés pour trouver le point d'attrape optimal
espace_entre_couleur = 10 # mm

# Coordoonées utiles
z_dessus = -53 #-45#-49 #mm
z_prise = -66 #-59 #mm
depot_rouge = (R_MAX,0) #(R_MAX, 0) # mm
depot_verte = (R_MAX - espace_entre_couleur,0)
depot_bleu = (R_MAX - 2*espace_entre_couleur,0)

# Parametre vitesse

# Pour connaitre la vitesse du tapis, on mesure le temps que met un cube pour parcourir une distance donnée. Par exemple, si un cube met 2 secondes pour parcourir 87.2 mm, alors la vitesse du tapis est de 87.2 mm / 2 s = 43.6 mm/s.
vitesse_tapis = 43.6 # mm/s
vitesse_robot = 100 #267.65 # mm/s
acceleration_robot = 2000 # 3374.50 # mm/s²
temps_descente = 0.988 # secondes descente + gripper (Valeur qui fonctionne pour la vitesse actuelle du robot mais qui doit être ajustée si la vitesse du robot est modifiée pour assurer que le robot arrive au point d'attrape au bon moment)
temps_latence_robot = 1.3 # secondes

# Caméra
port_webcam = 1
focus_cam = 20

y_origine_cam = 350
distance_robot_point = (242, -7) # Distance réelle du robot vers le point d'origine de la caméra calibrée avec la feuille attachée à la réglette 

# Matrice Translation Repere R0 (Rcam) => Rtapis (Rrobot)
trans_r0_to_rtapis = np.array([[distance_robot_point[0]], [distance_robot_point[1]+y_origine_cam], [0]])

# Matrice Rotation Repere R0 (Rcam) => Rtapis (Rrobot)
# rot_r0_to_rtapis = np.array([
#         [0, 1, 0],
#         [1, 0, 0],
#         [0, 0, -1]
#     ])

#Matrice Rotation Repere R0 (Rcam) => Rtapis (Rrobot) avec angle de rotation
rot_r0_to_rtapis = np.array([
    [-math.sin(angle_rad), math.cos(angle_rad), 0],
    [math.cos(angle_rad), math.sin(angle_rad), 0],
    [0, 0, -1]
])

attente_cubes = queue.Queue()
running = True

# --- Fonctions Vision ---

def pixel_to_mm(cx_px, cy_px):
    return [cx_px * px_en_mm, cy_px * px_en_mm]

def determiner_couleur(frame_bgr, centre_x, centre_y):
    # Sécurité pour ne pas sortir de l'image
    y_min = max(0, int(centre_y)-5)
    y_max = min(frame_bgr.shape[0], int(centre_y)+5)
    x_min = max(0, int(centre_x)-5)
    x_max = min(frame_bgr.shape[1], int(centre_x)+5)
    
    roi = frame_bgr[y_min:y_max, x_min:x_max]
    if roi.size == 0: return "Inconnu"

    mean_color = np.mean(roi, axis=(0, 1))
    b, g, r = mean_color 
    
    couleur = "Inconnu"
    if r > g and r > b:
        couleur = "Rouge"
    elif g > r and g > b:
        couleur = "Vert"
    elif b > r and b > g:
        couleur = "Bleu"

    return couleur

def detecter_carre(frame_bgr, cubes, t_capture, mask):
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (11, 11), 0)
    _, thresh = cv2.threshold(blurred, seuil, 255, cv2.THRESH_BINARY_INV)
    thresh = cv2.bitwise_and(thresh, thresh, mask=mask)

    # cv2.imshow("Seuil", thresh)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area_min < area < area_max:                  
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
            if len(approx) == 4: 
                rect = cv2.minAreaRect(cnt)
                (x_center, y_center), (w, h), angle_vision = rect
                couleur = determiner_couleur(frame_bgr, x_center, y_center)
                real_center_x = int(x_center) - x_center_frame_px
                real_center_y = int(y_center) - y_center_frame_px
                cx, cy = pixel_to_mm(real_center_x, real_center_y)

                cube_existant = False

                if cubes is not None:
                    for c in cubes:
                        pos_saved = c[0]
                        # On vérifie la distance pour savoir si c'est le même cube
                        if abs(pos_saved[0] - cx) < same_cube_distance and abs(pos_saved[1] - cy) < same_cube_distance:
                            c[0] = (cx, cy)
                            c[1] = angle_vision 
                            c[2] = t_capture
                            cube_existant = True
                            break
                    
                if not cube_existant:
                    cubes.append([(cx, cy), angle_vision, t_capture, couleur, None])

    for c in cubes[:]:
        pos, angle_vision, t_capture, couleur, time_remove = c

        if pos[0] < send_line and time_remove is None : # On vérifie que la position du cube a dépasser la ligne d'envoi et qu'il n'a pas déjà été envoyé
            
            vec_pos = np.array([[pos[0]], [pos[1]], [0]])
            centre_cube = np.add(trans_r0_to_rtapis, np.dot(rot_r0_to_rtapis, vec_pos))
            angle_robot = determiner_angle_robot(angle_vision) # Conversion de l'angle de la vision à l'angle du robot en optimisant l'angle pour que la pince soit la plus parallèle possible à l'axe y du robot pour evite les colisions avec le deplacement du tapis

            x_robot_mm = float(centre_cube[0][0])
            y_robot_mm = float(centre_cube[1][0])
            
            attente_cubes.put(((x_robot_mm, y_robot_mm), angle_robot, t_capture, couleur))
            c[4] = time.time()
            print(f"Cube envoyé à la file d'attente : {x_robot_mm:.1f}mm, {y_robot_mm:.1f}mm - Angle: {angle_robot:.1f}° - Horaire : {t_capture} - Couleur: {couleur}")
        
        elif time_remove is not None:
            if (time.time() - time_remove) > time_remove_after_sending:
                print(f"Cube supprimé de la mémoire")
                cubes.remove(c)
    return cubes

def isoler_zone_interet(frame):
    x_vision_px = int(x_vision / px_en_mm)
    y_vision_px = int(y_vision / px_en_mm)

    mask_offset_x_px = int(mask_offset_x / px_en_mm)    
    mask_offset_y_px = int(mask_offset_y / px_en_mm)
    
    h_img, w_img = frame.shape[:2] 
    cent_x, cent_y = w_img // 2, h_img // 2

    x1 = int(cent_x - (y_vision_px / 2) + mask_offset_x_px)
    x2 = int(cent_x + (y_vision_px / 2) + mask_offset_x_px)
    y1 = int(cent_y - (x_vision_px / 2) + mask_offset_y_px)
    y2 = int(cent_y + (x_vision_px / 2) + mask_offset_y_px)

    x1, x2 = max(0, x1), min(w_img, x2)
    y1, y2 = max(0, y1), min(h_img, y2)

    mask = np.zeros(frame.shape[:2], np.uint8)
    mask[y1:y2, x1:x2] = 255 

    return mask

def determiner_angle_robot(angle_cube_deg):
    angle_cube_rad = math.radians(angle_cube_deg)
    vecteur_vision = np.array([
        [math.cos(angle_cube_rad)], 
        [math.sin(angle_cube_rad)], 
        [0]
    ])

    vecteur_robot = np.dot(rot_r0_to_rtapis, vecteur_vision)
    angle_robot_rad = math.atan2(vecteur_robot[1, 0], vecteur_robot[0, 0])
    angle_robot_deg = math.degrees(angle_robot_rad)
    angle_optimise = (angle_robot_deg + 45) % 90 - 45

    return angle_optimise

# --- Fonctions Robot ---

def atteignable(x_rob):  
    try:
        ymin_grand = math.sqrt(R_MAX**2 - x_rob**2)
        ymax_grand = -math.sqrt(R_MAX**2 - x_rob**2)
    except ValueError:
        print("Cube hors de portee de la grande zone")
        return False

    try:
        ymin_petit = math.sqrt(R_MIN**2 - x_rob**2)
        ymax_petit = -math.sqrt(R_MIN**2 - x_rob**2)
        passage_min = True
    except ValueError:
        passage_min = False

    if passage_min:
        part_1 = (ymin_grand, ymin_petit)
        part_2 = (ymax_petit, ymax_grand)
        print(f"Recherche du point target sur l'axe x = {x_rob} dans [{ymin_grand}:{ymin_petit}] et dans [{ymax_petit},{ymax_grand}]")
    else :
        part_1 = (ymin_grand, ymax_grand)
        part_2 = None
        print(f"Recherche du point target sur l'axe x = {x_rob} dans [{ymin_grand}:{ymax_grand}]")
    
    return part_1, part_2

def temps_deplacement_robot(robot_pose, target_pose):
    # Temps pour atteindre V_max
    t_acc = vitesse_robot / acceleration_robot
    # Distance parcourue pendant l'accélération
    d_acc = 0.5 * acceleration_robot * (t_acc ** 2)
    d_triangle = 2 * d_acc
    
    # Correction index: [0]=x, [1]=y, [2]=z, [3]=r. 
    # On calcule la distance 3D, donc on utilise z_dessus vs robot_pose[2] (Z) et non [3] (R).
    z_actuel = robot_pose[2] if len(robot_pose) > 2 else z_dessus
    
    distance = math.sqrt(abs(robot_pose[0]-target_pose[0])**2 + abs(robot_pose[1]-target_pose[1])**2 + abs(z_actuel - z_dessus)**2)

    if distance >= d_triangle:
        dist_croisiere = distance - d_triangle
        t_croisiere = dist_croisiere / vitesse_robot
        temps_deplacement =  (2 * t_acc) + t_croisiere
    else:
        temps_deplacement = 2 * math.sqrt(distance / acceleration_robot)

    t_total = temps_deplacement + temps_descente + temps_latence_robot
    return t_total

def current_y_cube(cube_pos, t_capture):
    # Important: on travaille sur une copie ou on modifie l'objet ? 
    # Ici cube_pos est un tuple ou liste venant de la queue.
    # Pour éviter de modifier l'original si c'est une liste, on recrée une liste.
    new_y = cube_pos[1] - vitesse_tapis * (time.time() - t_capture)
    return [cube_pos[0], new_y]

def temps_cube(cube_pos, target_pos):
    temps_deplacement_cube = abs(cube_pos[1] - target_pos[1])/ vitesse_tapis
    return temps_deplacement_cube

def point_attrape(cube_pos, t_capture, pose_robot):
    range_a = atteignable(cube_pos[0])
    if range_a[0] is False:
        print("cube hors zone confirme")
        return False
    
    elif range_a[1] is None: # Pas de zone proche, que la grande zone
        current_pos = current_y_cube(cube_pos, t_capture)
        if current_pos[1] < range_a[0][1]: # Le cube a déjà dépassé la zone atteignable
            print("Cube hors de portee avant recherche")
            return False

        if current_pos[1] < range_a[0][0]: # Le cube est dans la zone atteignable, on peut commencer la recherche à sa position actuelle
            debut = int(current_pos[1])
            print(f"Recherche point target a y_cube_actuel = {current_pos[1]}")
        else : # Le cube n'est pas encore dans la zone atteignable, on peut commencer la recherche à la première position de la zone atteignable
            debut = int(range_a[0][0])
            print(f"Recherche point target a y_convenu = {range_a[0][0]}")

        for y in range(debut, int(range_a[0][1]), -pas_point_attrape): # On analyse les points de la zone atteignable en partant du plus proche du robot (y max) au plus éloigné (y min)
            temps_robot_deplacement = temps_deplacement_robot(pose_robot, (cube_pos[0], y))
            print(f"Temps déplacement robot pour aller à y = {y} de {temps_robot_deplacement} s")
            # Recalcul de la position courante pour l'estimation
            current_pos_now = current_y_cube(cube_pos, t_capture)
            temps_cube_deplacement = temps_cube(current_pos_now, (cube_pos[0], y))
            print(f"Temps déplacement cube de {temps_cube_deplacement} s")
            
            if temps_cube_deplacement>0 and temps_robot_deplacement < temps_cube_deplacement : # Si le cube n'est pas encore à ce point et que le robot peut y être avant le cube
                target_pose = (cube_pos[0], y)
                return target_pose
        return False
    
    else : # Il y a une zone proche et une zone éloignée
        current_pos = current_y_cube(cube_pos, t_capture)
        # Correction comparaison liste vs float
        if current_pos[1] < range_a[1][1]: # Le cube a déjà dépassé la zone atteignable
            print("Cube hors de portee avant recherche")
            return False # Ajout return

        # Recherche Partie 1
        if current_pos[1] < range_a[0][0]: # Le cube est dans la zone atteignable, on peut commencer la recherche à sa position actuelle
            debut = int(current_pos[1])
            print(f"Debut recherche point target a y_cube_actuel = {current_pos[1]} dans la premiere partie")
            if current_pos[1] < range_a[1][0]: # Le cube est déjà dans la seconde partie, on peut commencer la recherche à la position actuelle du cube
                print("Passage direct point target a y_cube_actuel dans la seconde partie")
                # Recherche directe seconde partie
                for y in range(debut, int(range_a[1][1]), -pas_point_attrape):
                    temps_robot_deplacement = temps_deplacement_robot(pose_robot, (cube_pos[0], y))

                    current_pos_now = current_y_cube(cube_pos, t_capture)
                    temps_cube_deplacement = temps_cube(current_pos_now, (cube_pos[0], y))
                    if temps_cube_deplacement>0 and temps_robot_deplacement < temps_cube_deplacement :
                        target_pose = (cube_pos[0], y)
                        return target_pose
                return False
        else : # Le cube n'est pas encore dans la zone atteignable, on peut commencer la recherche à la première position de la zone atteignable
            debut = int(range_a[0][0])
            print(f"Debut recherche point target a y_min_grand = {range_a[0][0]}")

        # Boucle Partie 1
        for y in range(debut, int(range_a[0][1]), -pas_point_attrape): # debut de la boucle à la position actuelle du cube ou à la première position de la zone atteignable
            temps_robot_deplacement = temps_deplacement_robot(pose_robot, (cube_pos[0], y))
            current_pos_now = current_y_cube(cube_pos, t_capture)
            temps_cube_deplacement = temps_cube(current_pos_now, (cube_pos[0], y))
            if temps_cube_deplacement>0 and temps_robot_deplacement < temps_cube_deplacement :
                target_pose = (cube_pos[0], y)
                return target_pose
        
        print(f"Premiere partie sans point target => Recherche maintenant point target a y_min_petit = {range_a[1][0]}")
        
        # Boucle Partie 2
        for y in range(int(range_a[1][0]), int(range_a[1][1]), -pas_point_attrape): # On analyse les points de la seconde zone atteignable en partant du plus proche du robot
            temps_robot_deplacement = temps_deplacement_robot(pose_robot, (cube_pos[0], y))
            current_pos_now = current_y_cube(cube_pos, t_capture)
            temps_cube_deplacement = temps_cube(current_pos_now, (cube_pos[0], y))
            if temps_cube_deplacement>0 and temps_robot_deplacement < temps_cube_deplacement :
                target_pose = (cube_pos[0], y)
                return target_pose
        return False

def nothing(x):
    pass

# --- THREADS ---

def thread_camera():

    global temps_descente, temps_latence_robot # Paramètres modifiables en temps réel avec les trackbars

    print("Démarrage caméra...")
    cap = cv2.VideoCapture(port_webcam, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, ecran_largeur)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, ecran_hauteur)
    
    cap.set(cv2.CAP_PROP_AUTOFOCUS, 0) # Autofocus camera desactive
    cap.set(cv2.CAP_PROP_FOCUS, focus_cam)

    # --- Création de la fenêtre de réglages ---
    cv2.namedWindow("Reglages Robot")
    cv2.resizeWindow("Reglages Robot", 400, 150)
    
    # Plage de 0 à 3000 ms (soit 0 à 3 secondes)
    cv2.createTrackbar("Descente (ms)", "Reglages Robot", int(temps_descente*1000), 3000, nothing)
    cv2.createTrackbar("Latence (ms)", "Reglages Robot", int(temps_latence_robot*1000), 6000, nothing)

    cubes = []

    while running:

        temps_descente = cv2.getTrackbarPos("Descente (ms)", "Reglages Robot") / 1000.0
        temps_latence_robot = cv2.getTrackbarPos("Latence (ms)", "Reglages Robot") / 1000.0

        ret, frame = cap.read()
        if not ret: break
        
        t_capture = time.time()
        
        mask = isoler_zone_interet(frame)
        cubes = detecter_carre(frame, cubes, t_capture, mask)

        for c in cubes: # Affichage des cubes détectés sur la caméra
            pos = c[0]
            angle = c[1]

            if c[4] is None:
                cx = int(pos[0] / px_en_mm) + x_center_frame_px
                cy = int(pos[1] / px_en_mm) + y_center_frame_px

                angle_rad = math.radians(angle)
                L = 15

                x1 = int(cx + L * math.cos(angle_rad))
                y1 = int(cy + L * math.sin(angle_rad))
                x2 = int(cx - L * math.cos(angle_rad))
                y2 = int(cy - L * math.sin(angle_rad))

                x3 = int(cx - L * math.sin(angle_rad))
                y3 = int(cy + L * math.cos(angle_rad))
                x4 = int(cx + L * math.sin(angle_rad))
                y4 = int(cy - L * math.cos(angle_rad))

                cv2.line(frame, (x1, y1), (x2, y2), (0, 255, 0), 1)
                cv2.line(frame, (x3, y3), (x4, y4), (0, 255, 0), 1)
        
        cv2.line(frame, (int(send_line/px_en_mm+x_center_frame_px), 0), (int(send_line/px_en_mm+x_center_frame_px), 1080), (0, 0, 255), 2)

        cv2.imshow("Vision Robot", frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

def thread_robot():
    print("Démarrage robot...")
    
    # --- Connexion Robot ---
    CON_STR = {
    dType.DobotConnect.DobotConnect_NoError:  "DobotConnect_NoError",
    dType.DobotConnect.DobotConnect_NotFound: "DobotConnect_NotFound",
    dType.DobotConnect.DobotConnect_Occupied: "DobotConnect_Occupied"}

    api = dType.load()
    state = dType.ConnectDobot(api, "", 115200)[0]
    print("Connect status:", CON_STR[state])

    if (state == dType.DobotConnect.DobotConnect_NoError):
        dType.SetQueuedCmdForceStopExec(api)
        dType.ClearAllAlarmsState(api)
        dType.SetQueuedCmdClear(api)
        dType.SetHOMEParams(api, 250, 0, 150, 0, isQueued = 1)
        dType.SetPTPJointParams(api, 200, 200, 200, 200, 200, 200, 200, 200, isQueued = 1)
        dType.SetPTPCommonParams(api, 100, 100, isQueued = 1)
        dType.SetEndEffectorParams(api, 59.7, 0, 0, isQueued=1)
        last_index = dType.SetHOMECmd(api, temp = 0, isQueued = 1)[0]
        dType.SetQueuedCmdStartExec(api)

        while True:
            current_index = dType.GetQueuedCmdCurrentIndex(api)[0]
            if current_index >= last_index:
                print("Robot prêt")
                break
            time.sleep(0.5)
            
        dType.SetEndEffectorGripper(api, 1, 0, isQueued=1) # Ouvrir la pince pour être sûr qu'elle est prête à attraper
        dType.SetWAITCmd(api, 200, isQueued=1) 
        dType.SetEndEffectorGripper(api, 0, 0, isQueued=1) # Stopper la pompe du gripper
        pose_actuelle = dType.GetPose(api)
        print(f"Pose actuelle : X={pose_actuelle[0]:.1f}, Y={pose_actuelle[1]:.1f}, Z={pose_actuelle[2]:.1f}, R={pose_actuelle[3]:.1f}")

    # --- Boucle Principale Robot ---
    
    while running:
        if not attente_cubes.empty():
            data_cube = attente_cubes.get() # Prend le cube le plus ancien dans la file d'attente
            pos_cube, angle_robot, t_capture, couleur = data_cube
            
            if couleur != "Inconnu" :
                pos_robot_total = dType.GetPose(api)
                pos_robotxy =[pos_robot_total[0],pos_robot_total[1]]
                pos_target = point_attrape(pos_cube, t_capture, pos_robotxy)

                if pos_target is not False : # Si un point d'attrape est trouvable pour ce cube
                    print("Target Point trouve : ", pos_target)
        
                    print("Angle de la pince : ", angle_robot)
                    
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_target[0], pos_target[1], z_dessus, angle_robot + offset_angle_robot, isQueued=1)
                    
                    temps_cube_target = temps_cube(pos_cube, pos_target)
                    print("Temps restant au cube pour aller a target point : ", temps_cube_target)
                    temps_avant_descente = temps_cube_target - temps_descente
                    print("Temps a attendre avant descente du robot : ", temps_avant_descente)

                    # BOUCLE D'ATTENTE AVANT DESCENTE
                    print("Temps actuel : ", time.time() - t_capture)
                    while (time.time() - t_capture) < temps_avant_descente:
                        time.sleep(0.0001)
                    
                    print("Descente Robot")
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_target[0], pos_target[1], z_prise, angle_robot + offset_angle_robot, isQueued=1)
                    # while True :
                    #     current_index = dType.GetQueuedCmdCurrentIndex(api)[0]
                    #     if current_index >= index_descente:
                    #         break
                    #     time.sleep(0.001)
                    # time.sleep(temps_pince_attente)
                    dType.SetEndEffectorGripper(api, 1, 1, isQueued=1) # Fermer la pince pour attraper le cube
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_target[0], pos_target[1], z_dessus, offset_angle_robot, isQueued=1)
                    
                    pos_depot = depot_rouge # Par défaut pour éviter une erreur si jamais la couleur n'est pas reconnue même si ça ne devrait pas arriver avec la présence du if couleur != "Inconnu" plus haut
                    if couleur == "Rouge":
                        pos_depot = depot_rouge
                        print("Deplacement robot vers depot rouge")
                    elif couleur == "Bleu":
                        pos_depot = depot_bleu
                        print("Deplacement robot vers depot bleu")
                    elif couleur == "Vert":
                        pos_depot = depot_verte
                        print("Deplacement robot vers depot verte")
                    
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_depot[0], pos_depot[1], z_dessus, offset_angle_robot, isQueued=1)
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_depot[0], pos_depot[1], z_prise, offset_angle_robot, isQueued=1)
                    dType.SetEndEffectorGripper(api, 1, 0, isQueued=1) # Ouvrir la pince pour lâcher le cube
                    dType.SetWAITCmd(api, 600, isQueued=1) 
                    dType.SetEndEffectorGripper(api, 0, 0, isQueued=1) # Stopper la pompe du gripper
                    dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, pos_depot[0], pos_depot[1], z_dessus, offset_angle_robot, isQueued=1)
                else:
                    print("Aucun target point de trouve, cube deja hors de portee")    
            else :
                print("Couleur Inconnu")
        else:
            time.sleep(0.1)
        
    dType.SetQueuedCmdStopExec(api)
    dType.DisconnectDobot(api)
    print("Robot déconnecté.")

# --- MAIN ---

if __name__ == "__main__":
    thread_vis = threading.Thread(target=thread_camera)
    thread_rob = threading.Thread(target=thread_robot)

    thread_vis.start()
    thread_rob.start()

    print("Système lancé")

    try:
        while True:
            if not thread_vis.is_alive():
                running = False
                break
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nArrêt demandé...")
        running = False

    thread_vis.join()
    thread_rob.join()
    print("Programme terminé.")