import cv2
import numpy as np
import math

# --- CONFIGURATION ---
port_webcam = 1
focus_cam = 25 

cap = cv2.VideoCapture(port_webcam, cv2.CAP_DSHOW)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
cap.set(cv2.CAP_PROP_FOCUS, focus_cam)

win_name = "Calibration: Origine & Reference"
cv2.namedWindow(win_name)

def nothing(x): pass

# Création des Trackbars
cv2.createTrackbar("X Coarse", win_name, 500, 1000, nothing)
cv2.createTrackbar("Y Coarse", win_name, 500, 1000, nothing)

# --- VARIABLES D'ÉTAT ---
active_point = 0 
pt_a_data = [0, 0, 0, 0]
pt_b_data = [100, 0, 0, 0] 

print("--- CALIBRATION ---")
print("[TAB] : Changer Point A (Origine) <-> Point B (Ref)")
print("[Q]   : Quitter et voir les résultats")

while True:
    ret, frame = cap.read()
    if not ret: break
    h_img, w_img = frame.shape[:2]
    cx_cam, cy_cam = w_img // 2, h_img // 2

    key = cv2.waitKeyEx(1)
    if key == 9: # Touche TAB pour basculer entre les points
        active_point = 1 - active_point
        target_data = pt_b_data if active_point == 1 else pt_a_data
        cv2.setTrackbarPos("X Coarse", win_name, target_data[0] + 1000)
        cv2.setTrackbarPos("Y Coarse", win_name, target_data[1] + 1000)

    # Récupération et mise à jour des données
    current_data = pt_b_data if active_point == 1 else pt_a_data
    current_data[0] = cv2.getTrackbarPos("X Coarse", win_name) - 1000
    current_data[1] = cv2.getTrackbarPos("Y Coarse", win_name) - 1000

    # Gestion flèches
    
    if key == 2555904:   # Flèche Droite
        current_data[2] += 1
    elif key == 2424832: # Flèche Gauche
        current_data[2] -= 1
    elif key == 2621440: # Flèche Bas
        current_data[3] += 1
    elif key == 2490368: # Flèche Haut
        current_data[3] -= 1
    elif key == ord('r'): 
        current_data[2] = 0; current_data[3] = 0
    elif key & 0xFF == ord('x'): # Touche x pour sortir aussi
        break 

    # Calcul positions absolues (Pixels image)
    # Point A (Origine caméra)
    ax_px = cx_cam + pt_a_data[0] + pt_a_data[2]
    ay_px = cy_cam + pt_a_data[1] + pt_a_data[3]
    pos_A = (ax_px, ay_px)

    # Point B (Point de référence)
    bx_px = cx_cam + pt_b_data[0] + pt_b_data[2]
    by_px = cy_cam + pt_b_data[1] + pt_b_data[3]
    pos_B = (bx_px, by_px)

    # Calculs Delta
    dx = bx_px - ax_px
    dy = by_px - ay_px # Y image descend 

    # Distance et Angle
    dist_px = math.sqrt(dx**2 + dy**2)
    # Angle en degrés par rapport à l'horizontale caméra
    angle_deg = math.degrees(math.atan2(dy, dx))

    # --- AFFICHAGE ---
    cv2.line(frame, pos_A, pos_B, (255, 255, 0), 1) 

    # Point A
    cv2.line(frame, (0, ay_px), (w_img, ay_px), (0, 255, 0), 1) 
    cv2.line(frame, (ax_px, 0), (ax_px, h_img), (0, 255, 0), 1)
    cv2.putText(frame, f"ORIGINE (OFFSET): {ax_px}, {ay_px}", (ax_px+10, ay_px-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Point B
    cv2.line(frame, (0, by_px), (w_img, by_px), (0, 255, 255), 1) 
    cv2.line(frame, (bx_px, 0), (bx_px, h_img), (0, 255, 255), 1)

    # Overlay Info
    cv2.rectangle(frame, (20, 20), (450, 160), (0, 0, 0), -1)
    cv2.putText(frame, f"OFFSET X (Origine): {ax_px} px", (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, f"OFFSET Y (Origine): {ay_px} px", (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, f"Distance : {dist_px:.2f} px", (30, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 255), 1)
    cv2.putText(frame, f"Angle    : {(180+angle_deg):.2f} deg", (30, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 255), 1)

    cv2.imshow(win_name, frame)

cap.release()
cv2.destroyAllWindows()

print("\n" + "="*50)
print("   PARAMÈTRES DE TRANSFORMATION")
print("="*50)
print(f"OFFSET_X = {ax_px}  (À soustraire de x_cam)")
print(f"OFFSET_Y = {ay_px}  (À soustraire de y_cam)")
print(f"ANGLE_CORRECTION = {angle_deg} degrés")
print(f"DISTANCE_PIXELS = {dist_px} px")
print("="*50 + "\n")