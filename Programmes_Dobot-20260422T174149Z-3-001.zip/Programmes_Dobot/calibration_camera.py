import cv2
import numpy as np

# Fonction vide nécessaire pour les trackbars OpenCV
def nothing(x):
    pass

# --- PARAMÈTRES INITIAUX ---
ecran_largeur = 1920
ecran_hauteur = 1080
port_webcam = 1

# Création de la fenêtre de calibration et des curseurs (Trackbars)
cv2.namedWindow("Calibration")
cv2.resizeWindow("Calibration", 600, 250)

cv2.createTrackbar("Focus Cam", "Calibration", 25, 255, nothing)
cv2.createTrackbar("Seuil", "Calibration", 100, 255, nothing)
cv2.createTrackbar("Area Min", "Calibration", 400, 5000, nothing)
cv2.createTrackbar("Area Max", "Calibration", 3000, 10000, nothing)

print("Démarrage de la caméra de calibration...")
cap = cv2.VideoCapture(port_webcam, cv2.CAP_DSHOW)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, ecran_largeur)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, ecran_hauteur)
cap.set(cv2.CAP_PROP_AUTOFOCUS, 0) # Désactive l'autofocus

while True:
    ret, frame = cap.read()
    if not ret:
        print("Erreur de lecture de la caméra.")
        break

    # Récupération des valeurs actuelles
    current_focus = cv2.getTrackbarPos("Focus Cam", "Calibration")
    current_seuil = cv2.getTrackbarPos("Seuil", "Calibration")
    current_area_min = cv2.getTrackbarPos("Area Min", "Calibration")
    current_area_max = cv2.getTrackbarPos("Area Max", "Calibration")

    # Application du focus
    cap.set(cv2.CAP_PROP_FOCUS, current_focus)

    # Traitement de l'image (le même qui est utilisé dans "Dobot_sequence.py")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (11, 11), 0)
    _, thresh = cv2.threshold(blurred, current_seuil, 255, cv2.THRESH_BINARY_INV)

    # Détection des contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Copie de l'image
    frame_contours = frame.copy()

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if current_area_min < area < current_area_max:
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
            
            # Si c'est un cube
            if len(approx) == 4:
                # Dessine le contour validé en vert
                cv2.drawContours(frame_contours, [approx], -1, (0, 255, 0), 3)
                
                # Ajoute le centre et l'aire pour info
                M = cv2.moments(cnt)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    cv2.circle(frame_contours, (cx, cy), 5, (0, 0, 255), -1)
                    cv2.putText(frame_contours, f"Aire: {int(area)}", (cx - 20, cy - 20), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    # Affichage des rendus
    frame_resized = cv2.resize(frame_contours, (960, 540))
    thresh_resized = cv2.resize(thresh, (960, 540))
    
    cv2.imshow("Detection en direct", frame_resized)
    cv2.imshow("Masque Noir & Blanc (Seuil)", thresh_resized)

    # Quitter avec la touche 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        # Affiche les valeurs finales dans la console
        print("\n--- VALEURS DE CALIBRATION RETENUES ---")
        print(f"focus_cam = {current_focus}")
        print(f"seuil = {current_seuil}")
        print(f"area_min = {current_area_min}")
        print(f"area_max = {current_area_max}")
        print("---------------------------------------")
        break

cap.release()
cv2.destroyAllWindows()